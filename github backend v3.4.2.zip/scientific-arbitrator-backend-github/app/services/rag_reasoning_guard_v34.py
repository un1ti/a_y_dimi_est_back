"""v3.4 conservative post-generation guardrails for citation-bound research comparisons.

Checks *explicit terms* against the exact selected PDF excerpts.  This is NOT
semantic entailment, author-attribution verification, or scientific certification.
No LLM calls, filesystem access, or database writes are performed here.
"""
from __future__ import annotations

import re
from typing import Any


# Every alias below is intentionally conservative. The goal is to catch
# conspicuous unsupported facts (models/metrics/parameters), not infer meaning.
TECHNICAL_ANCHORS = {
    'bm25': r'\bbm25\b',
    'tf-idf': r'\btf[- ]?idf\b',
    'recall@k': r'\brecall\s*@\s*(?:k|𝑘|\d+)\b',
    'f1': r'\bf1\b',
    'exact match': r'\bexact.match\b',
    'nomic-embed-text': r'\bnomic[- ]embed[- ]text\b',
    'text-embedding-ada-002': r'\b(?:text[- ]embedding[- ]ada[- ]002|ada[- ]002)\b',
    'gpt-4o-mini': r'\bgpt[- ]?4o[- ]mini\b',
    'gpt-4o': r'\bgpt[- ]?4o\b',
    'gpt-4': r'\bgpt[- ]?4(?!o|[a-z0-9])',
    'semantic topology graph': r'\b(?:semantic topology graph|stg)\b',
    'graph': r'\b(?:graphs?|graphical)\b|граф\w*',
    'node': r'\bnodes?\b|узл\w*',
    'embedding': r'\b(?:embeddings?|embedder)\b|эмбед\w*',
    'reranking': r'\brerank\w*\b|реранк\w*',
    'training': r'\b(?:training|trained|fine[- ]?tun\w*|instruction[- ]?tuning)\b|(?:до)?обуч\w*',
    'hybrid retrieval': r'\bhybrid\b|гибридн\w*',
}
_PATTERNS = {k: re.compile(v, re.I) for k, v in TECHNICAL_ANCHORS.items()}
_UNSUPPORTED_ABSENCE = re.compile(
    r'\b(?:does not (?:use|contain|include)|is absent|not used|never uses)\b'
    r'|\b(?:отсутств\w*|не\s+(?:использ\w*|применя\w*|содерж\w*))\b', re.I)
_UNSUPPORTED_PERFORMANCE = re.compile(
    r'\b(?:outperform\w*|superior|best performance|statistically significant)\b'
    r'|(?:превосход\w*|эффективнее|точнее|статистически значим\w*)', re.I)
_MISSING_EXPERIMENTS = re.compile(
    r'\b(?:no experimental results?|absence of experimental results?|no experiments?)\b'
    r'|(?:отсутстви\w*\s+экспериментальн\w*\s+результат\w*|нет\s+экспериментальн\w*\s+результат\w*)',
    re.I,
)
_CITE_TOKENS = re.compile(r'\b[LR]-(?:[a-z]+(?:_[a-z]+)*)-\d+\b')
_NUMBERS = re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')


def role_hint(excerpt: str) -> str:
    """Weak role *candidate* from literal wording, never a certified label."""
    if re.search(r'\b(?:baseline|vanilla[- ]?rag|compared with|comparison against|existing methods)\b', excerpt, re.I):
        return 'possible_baseline_context'
    if re.search(r'\b(?:we propose|our proposed|we introduce|our method|we develop)\b', excerpt, re.I):
        return 'possible_author_method'
    return 'role_not_established'


def check_claim(text: str, evidence_ids: list[str], catalog: dict[str, dict]) -> dict[str, Any]:
    """Test named technical entities/parameters against *cited* source excerpts.

    This cannot check paraphrase entailment. A passing check means literal
    anchors are present, NOT that a scientific interpretation is valid.
    """
    quoted = '\n'.join(str(catalog[x].get('quote', '')) for x in evidence_ids if x in catalog)
    clean_claim = _CITE_TOKENS.sub(' ', text or '')
    required = [name for name, pattern in _PATTERNS.items() if pattern.search(clean_claim)]
    # Avoid counting hierarchical terms as separate unsupported assertions.
    if 'text-embedding-ada-002' in required or 'nomic-embed-text' in required:
        required = [x for x in required if x != 'embedding']
    if 'semantic topology graph' in required:
        required = [x for x in required if x != 'graph']
    if 'gpt-4o-mini' in required and 'gpt-4o' in required:
        required.remove('gpt-4o')
    missing = [name for name in required if not _PATTERNS[name].search(quoted)]
    if 'hybrid retrieval' in missing and re.search(r'\bbm25\b', quoted, re.I) and re.search(r'\b(?:dense|vector|semantic)\b', quoted, re.I):
        # Explicit BM25 + dense/semantic retrieval together warrants this label.
        missing.remove('hybrid retrieval')
    roles = sorted({role_hint(str(catalog[x].get('quote', ''))) for x in evidence_ids if x in catalog})
    # Numeric parameters must be present literally; numbers in citations are stripped.
    numbers = set(_NUMBERS.findall(clean_claim))
    quote_numbers = set(_NUMBERS.findall(quoted))
    missing.extend('number:' + n for n in sorted(numbers - quote_numbers))
    if _UNSUPPORTED_ABSENCE.search(clean_claim):
        missing.append('unproved_absence')
    if _UNSUPPORTED_PERFORMANCE.search(clean_claim):
        missing.append('unverified_superiority')
    if _MISSING_EXPERIMENTS.search(clean_claim):
        missing.append('unverified_absence_of_results')
    if roles and all(x == 'possible_baseline_context' for x in roles):
        # A baseline setup must not be presented as the authors' method.
        if re.search(r'\b(?:использу\w*|применя\w*|uses?|implements?|authors?\s+uses?)\b', clean_claim, re.I) and not re.search(r'baseline|vanilla|базов\w*|для сравнени\w*', clean_claim, re.I):
            missing.append('possible_baseline_misattribution')
    return {
        'status': ('unsupported_specifics' if missing else
                   'technical_anchors_present_not_entailment' if required or numbers else
                   'not_machine_assessed'),
        'checked_anchor_terms': required,
        'unsupported_anchor_terms': missing,
        'source_role_hints': roles,
        'scientific_entailment_verified': False,
    }


def protect_comparison(entry: dict, catalog: dict, *, language: str) -> dict:
    """Suppress unsupported factual specifics in public-facing method fields."""
    ids_l, ids_r = entry['left_evidence_ids'], entry['right_evidence_ids']
    checks = {
        'left_method': check_claim(entry['left_method'], ids_l, catalog),
        'right_method': check_claim(entry['right_method'], ids_r, catalog),
        'similarity': check_claim(entry['similarity'], ids_l + ids_r, catalog),
        'difference': check_claim(entry['difference'], ids_l + ids_r, catalog),
        'left_advantage': check_claim(entry['left_advantage'], ids_l, catalog),
        'right_advantage': check_claim(entry['right_advantage'], ids_r, catalog),
    }
    unsupported = [key for key, obj in checks.items() if obj['status'] == 'unsupported_specifics']
    # Do not print unproven model-generated claims in the main explanation.
    fallback = ('Недостаточно доказательств в указанных цитатах.' if language == 'ru'
                else 'Insufficient support in the cited excerpts.')
    for key in unsupported:
        if key in ('left_method', 'right_method'):
            side_ids = ids_l if key == 'left_method' else ids_r
            quote_data = next((catalog.get(x, {}) for x in side_ids if catalog.get(x, {}).get('quote')), {})
            excerpt = ' '.join(str(quote_data.get('quote', '')).split())[:160]
            page = quote_data.get('page')
            if excerpt:
                entry[key] = ((f'Исходная цитата, стр. {page}: «{excerpt}». Интерпретация модели отклонена.'
                               if language == 'ru' else
                               f'Original PDF excerpt, page {page}: “{excerpt}”. Model interpretation rejected.'))
                continue
        entry[key] = fallback
    entry['claim_support_checks'] = checks
    entry['redacted_unsupported_fields'] = unsupported
    entry['attribution_verified'] = False
    entry['scientific_verification'] = 'requires_human_review'
    return entry


def safe_summary(comparisons: list[dict], language: str) -> str:
    if not comparisons:
        return ''
    topics = ', '.join(x['label'] for x in comparisons[:5])
    return (f'Найдено тематических сопоставлений: {len(comparisons)} ({topics}). '
            'Сведения о методах предварительные. Численное превосходство не подтверждено.'
            if language == 'ru' else
            f'Thematic comparisons: {len(comparisons)} ({topics}). '
            'Method details remain preliminary; performance superiority is not established.')


def clean_limitations(items: list[str], *, language: str) -> list[str]:
    replacement = ('Численные результаты могут присутствовать в PDF, но не включены в этот LLM-контекст.'
                   if language == 'ru' else
                   'Numerical results may exist in the PDFs but are not included in this LLM context.')
    return [replacement if _MISSING_EXPERIMENTS.search(x) else x for x in items]
