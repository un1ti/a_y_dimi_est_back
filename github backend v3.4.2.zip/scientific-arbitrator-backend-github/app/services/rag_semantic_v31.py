"""v3.1: conservative, source-linked thematic comparison of two RAG papers.

The output contains candidate textual overlap, not scientific equivalence. Every
nonempty side of a topic links back to a literal fragment quote.
"""
from __future__ import annotations

import re
from typing import Any

# A curated taxonomy avoids suggesting that superficial textual similarity proves
# equivalent implementations. Terms are deliberately distinct and domain-bound.
TOPICS: dict[str, tuple[str, tuple[str, ...]]] = {
    'retrieval': ('Document retrieval', (r'\bretriev(?:al|er|ing|ed)\b', r'\bsemantic search\b', r'\bBM25\b')),
    'embedding': ('Embedding representations', (r'\bembeddings?\b', r'\bembedder\b', r'\bdense vectors?\b')),
    'reranking': ('Reranking', (r'\brerank(?:ing|er|ed)?\b', r'\bcross.encoder\b')),
    'generation': ('Answer generation', (r'\banswer generation\b', r'\bgenerat(?:ion|or|ing)\b', r'\bLLM(?:s)?\b')),
    'knowledge_graph': ('Knowledge graphs', (r'\bknowledge graphs?\b', r'\bKGs?\b', r'\bgraph.based\b')),
    'multi_hop': ('Multi-hop reasoning', (r'\bmulti.hop\b', r'\b(?:two|2).hop\b', r'\bcomplex reasoning\b')),
    'benchmark': ('Benchmarking and evaluation', (r'\bbenchmark\b', r'\bevaluat(?:ion|ing|ed)\b')),
    'document_qa': ('Document question answering', (r'\bdocumentation QA\b', r'\bdocument question.answering\b', r'\bdocument QA\b')),
}
COMPILED = {k: tuple(re.compile(x, re.I) for x in patterns) for k, (_, patterns) in TOPICS.items()}


def _fragment_lines(raw: str) -> list[str]:
    """Use existing boundaries; never assemble quotes across lines/columns."""
    if raw.lstrip().startswith('EXTRACTED TABLE ('):
        return []
    lines: list[str] = []
    for line in raw.splitlines():
        s = ' '.join(line.split())
        if 24 <= len(s) <= 280 and not s.startswith(('Columns:', 'Row:', 'http')):
            # Reject clear mixed table/prose snippets. Other column bleed is
            # possible and explicitly acknowledged as an uncertainty.
            if s.count(' | ') >= 2:
                continue
            lines.append(s)
    return lines


def topic_evidence(fragments: list[Any], *, per_topic: int = 3) -> dict[str, list[dict]]:
    if not 1 <= per_topic <= 10:
        raise ValueError('per_topic must be in 1..10')
    evidence: dict[str, list[dict]] = {k: [] for k in TOPICS}
    seen: set[tuple] = set()
    for frag in fragments:
        page = getattr(frag, 'page', None)
        fragment_id = getattr(frag, 'id', None)
        if page is None or fragment_id is None:
            continue
        for line in _fragment_lines(str(getattr(frag, 'text', '') or '')):
            for topic, patterns in COMPILED.items():
                if len(evidence[topic]) >= per_topic or not any(p.search(line) for p in patterns):
                    continue
                key = (topic, int(page), line.casefold())
                if key in seen:
                    continue
                seen.add(key)
                evidence[topic].append({
                    'page': int(page), 'fragment_id': str(fragment_id), 'quote': line,
                    'status': 'candidate_requires_review',
                })
    return evidence


def semantic_compare(left_fragments: list[Any], right_fragments: list[Any], *, per_topic: int = 3) -> dict:
    left = topic_evidence(left_fragments, per_topic=per_topic)
    right = topic_evidence(right_fragments, per_topic=per_topic)
    shared, left_only, right_only = [], [], []
    for topic, (label, _) in TOPICS.items():
        a, b = left[topic], right[topic]
        if not a and not b:
            continue
        item = {
            'topic': topic, 'label': label,
            'left_evidence': a, 'right_evidence': b,
            'interpretation': ('topic_mentioned_in_both_not_method_equivalence' if a and b
                               else 'topic_mentioned_in_one_document_only'),
        }
        if a and b:
            shared.append(item)
        elif a:
            left_only.append(item)
        else:
            right_only.append(item)
    return {
        'shared_topic_count': len(shared),
        'left_only_topic_count': len(left_only),
        'right_only_topic_count': len(right_only),
        'shared_topics': shared, 'left_only_topics': left_only, 'right_only_topics': right_only,
        'method_equivalence_verified': False,
        'scientific_superiority_verdict': 'insufficient_data',
        'evidence_status': 'candidate_requires_review',
        'limitations': [
            'Keyword/topic matches are not proof that two systems use the same methods.',
            'Quotes preserve stored fragment lines; PDF extraction may interleave columns.',
            'Absence of a topic match is not proof that the paper does not discuss the topic.',
            'No LLM fact verification, cross-document entailment, or protocol certification is performed.',
        ],
    }
