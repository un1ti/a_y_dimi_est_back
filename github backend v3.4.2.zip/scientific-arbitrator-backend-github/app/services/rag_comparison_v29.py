"""Conservative read-only benchmark comparison. Never infer experimental metadata."""
from __future__ import annotations
import re
from typing import Any

METRICS_WITH_K = {'recall', 'precision', 'ndcg', 'map', 'hit', 'mrr'}
ALIASES = {'em': 'exactmatch', 'exactmatch': 'exactmatch'}


def _metric(s: str) -> str:
    s = re.sub(r'[\s_-]+', '', s.strip().casefold())
    return ALIASES.get(s, s)


def _known(value: Any) -> bool:
    return value is not None and (not isinstance(value, str) or bool(value.strip()))


def _eq(a: Any, b: Any) -> bool:
    return str(a).strip().casefold() == str(b).strip().casefold()


def compare_previews(left: dict, right: dict) -> dict:
    """Three-valued decision; missing stage/protocol/split never implies equality.

    Optional experimental metadata is *caller-supplied*, not verified automatically.
    A comparable result is conditional on its correctness.
    """
    differences, missing, checked = [], [], []
    for key in ('metric', 'dataset'):
        a, b = left.get(key), right.get(key)
        if not _known(a) or not _known(b):
            missing.append(key)
        else:
            checked.append(key)
            if (_metric(str(a)) if key == 'metric' else str(a).strip().casefold()) != (_metric(str(b)) if key == 'metric' else str(b).strip().casefold()):
                differences.append(key)
    lm, rm = _metric(str(left.get('metric') or '')), _metric(str(right.get('metric') or ''))
    if lm in METRICS_WITH_K or rm in METRICS_WITH_K:
        if not _known(left.get('metric_k')) or not _known(right.get('metric_k')):
            missing.append('metric_k')
        else:
            checked.append('metric_k')
            if str(left['metric_k']) != str(right['metric_k']):
                differences.append('metric_k')
    for key in ('evaluation_stage', 'evaluation_protocol', 'split'):
        a, b = left.get(key), right.get(key)
        if not _known(a) or not _known(b):
            missing.append(key)
        else:
            checked.append(key)
            if not _eq(a, b):
                differences.append(key)
    # If known, explicit experimental evaluation scope and units also matter.
    for key in ('evaluation_scope', 'metric_unit', 'aggregation'):
        a, b = left.get(key), right.get(key)
        if _known(a) and _known(b):
            checked.append(key)
            if not _eq(a, b):
                differences.append(key)
        elif _known(a) != _known(b):
            missing.append(key)
    verdict = 'incomparable' if differences else 'insufficient_data' if missing else 'comparable'
    reasons = []
    if differences: reasons.append('Mismatched experimental conditions: ' + ', '.join(differences))
    if missing: reasons.append('Unverified or missing context: ' + ', '.join(missing))
    if verdict == 'comparable': reasons.append('All supplied required conditions match; independent source review is still required.')
    return {'verdict': verdict, 'blocking_fields': list(dict.fromkeys(differences + missing)),
            'compared_fields': checked, 'reasons': reasons,
            'source_references': {'left': {'page': left.get('source_page'), 'fragment_id': left.get('fragment_id')},
                                  'right': {'page': right.get('source_page'), 'fragment_id': right.get('fragment_id')}},
            'metadata_status': 'caller_supplied_not_independently_verified',
            'note': 'Read-only preliminary comparability. Comparable does not certify correctness, equivalence or superiority.'}


def audit_preview(records: list[dict]) -> dict:
    """Count metric families; identify context missing before comparing methods."""
    from collections import defaultdict
    groups = defaultdict(lambda: {'count': 0, 'systems': set(), 'pages': set()})
    for r in records:
        key = (r.get('dataset'), r.get('metric'), r.get('metric_k'))
        item = groups[key]
        item['count'] += 1
        item['systems'].add(str(r.get('system') or ''))
        if r.get('source_page') is not None: item['pages'].add(r['source_page'])
    return {'total_records': len(records),
            'families': [{'dataset': k[0], 'metric': k[1], 'metric_k': k[2],
                          'record_count': v['count'], 'systems_count': len(v['systems']),
                          'source_pages': sorted(v['pages']),
                          'readiness': 'insufficient_data',
                          'missing_required_context': ['evaluation_stage', 'evaluation_protocol', 'split']}
                         for k,v in sorted(groups.items(), key=lambda p:(str(p[0][0]), str(p[0][1]), str(p[0][2])))],
            'note': 'Grouping does not certify comparability. Experimental stages/protocols/splits are not inferred from metric names or PDF page numbers.'}
