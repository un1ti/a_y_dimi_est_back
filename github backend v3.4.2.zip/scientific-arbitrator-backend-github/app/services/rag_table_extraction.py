"""Conservative, deterministic extraction from structurally detected RAG PDF tables.

Only processes explicit EXTRACTED TABLE fragments made by pdf_parser.extract_table_fragments.
A cell value is associated with the header from the SAME table fragment and row index.
Plain PDF text is deliberately not interpreted as a grid. Nothing is inferred from
neighbouring paragraphs, dataset reputation, or numerical similarity alone.

This is source traceability, NOT independent scientific validation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable

from app.db.models import SourceFragment

_NUM = re.compile(r"^\s*([-+]?(?:\d+(?:[.,]\d*)?|\.\d+))\s*(%)?\s*$")
_SYSTEM_HEADERS = frozenset({"system", "method", "methods", "model", "approach", "rag variant", "rag system", "configuration", "baseline", "retriever", "model type", "rag flow"})
_DATASET_HEADERS = frozenset({"dataset", "benchmark", "data set", "corpus", "test set"})
_METRIC = re.compile(
    r"(?<![A-Za-z])(?P<name>Exact\s+Match|EM|F1|Recall|Precision|NDCG|MRR|Hit\s*Rate|Hit@\d+|Accuracy|BLEU|ROUGE[- ]?L|UniEval)"
    r"(?:\s*@\s*(?P<k>\d+))?(?![A-Za-z])", re.IGNORECASE,
)
_KNOWN_DATASETS = (
    "HotpotQA", "2WikiMultiHopQA", "2Wiki", "MuSiQue", "TriviaQA", "Natural Questions",
    "NQ", "WebQuestions", "WQ", "PopQA", "FEVER", "ASQA", "Bamboogle", "SQuAD", "WikiQA",
)
_MAX_TABLE_FRAGMENTS = 1200
_MAX_RECORDS = 600


@dataclass(frozen=True)
class TableExtraction:
    records: list[dict[str, Any]]
    table_fragment_count: int
    skipped_rows: int
    complete_context_count: int
    duplicate_count: int = 0
    conflicting_groups: int = 0
    skipped_details: tuple[dict[str, Any], ...] = ()


def _header_kind(header: str) -> str | None:
    raw = re.sub(r"\s+", " ", header.strip().casefold())
    if raw in _SYSTEM_HEADERS:
        return "system"
    if raw in _DATASET_HEADERS:
        return "dataset"
    return None


def _metric_spec(label: str) -> tuple[str | None, int | None]:
    found = list(_METRIC.finditer(label))
    if len(found) != 1:
        return None, None
    hit = found[0]
    literal = re.sub(r"\s+", " ", hit.group("name")).strip().casefold()
    name = {
        "em": "Exact Match", "exact match": "Exact Match", "f1": "F1",
        "recall": "Recall", "precision": "Precision", "ndcg": "NDCG",
        "mrr": "MRR", "accuracy": "Accuracy", "hit rate": "Hit Rate",
        "bleu": "BLEU", "rouge-l": "ROUGE-L", "rouge l": "ROUGE-L", "unieval": "UniEval",
    }.get(literal, "Hit Rate" if literal.startswith("hit@") else None)
    k = int(hit.group("k")) if hit.group("k") else None
    if literal.startswith("hit@"):
        k = int(literal.split("@")[1])
    return name, k


def _dataset_from_heading(heading: str) -> str | None:
    for name in _KNOWN_DATASETS:
        if re.search(r"(?<![A-Za-z0-9])" + re.escape(name) + r"(?![A-Za-z0-9])", heading, re.I):
            return name
    # An arbitrary dataset name may be explicit in a header like "MyQA (Exact Match)".
    metric, _ = _metric_spec(heading)
    if metric is None:
        return None
    cleaned = _METRIC.sub("", heading).strip(" \t\r\n:-_/()[]%")
    if re.fullmatch(r"[A-Za-z0-9][\w.#& +\-]{1,75}", cleaned) and cleaned.casefold() not in ("score", "result", "metric", "performance"):
        return cleaned
    return None


def _system_from_heading(heading: str) -> str | None:
    metric, _ = _metric_spec(heading)
    if metric is None:
        return None
    cleaned = _METRIC.sub("", heading).strip(" \t\r\n:-_/()[]%")
    if re.fullmatch(r"[A-Za-z][\w.*+ -]{1,65}", cleaned):
        return cleaned
    return None


def _evidence(field: str, frag: SourceFragment, quote: str) -> dict[str, str]:
    # Direct substring from a single fragment, verified again by ground_record.
    return {"field": field, "fragment_id": frag.id, "quote": quote}


def _parse_one(frag: SourceFragment, diagnostics: list[dict[str, Any]] | None = None) -> tuple[list[dict[str, Any]], int]:
    lines = frag.text.splitlines()
    if not lines or not lines[0].strip().startswith("EXTRACTED TABLE ("):
        return [], 0
    header_lines = [line for line in lines if line.startswith("Columns: ")]
    if len(header_lines) != 1:
        return [], 0
    header_quote = header_lines[0]
    headers = [x.strip() for x in header_quote.removeprefix("Columns: ").split("|")]
    if not (2 <= len(headers) <= 60):
        return [], 0
    kinds = [_header_kind(h) for h in headers]
    system_cols = [i for i, k in enumerate(kinds) if k == "system"]
    dataset_cols = [i for i, k in enumerate(kinds) if k == "dataset"]
    if len(system_cols) > 1 or len(dataset_cols) > 1 or (not system_cols and not dataset_cols):
        return [], 0
    system_col = system_cols[0] if system_cols else None
    dataset_col = dataset_cols[0] if dataset_cols else None
    # A caption/metric must be present in THIS SAME fragment to be used.
    context_lines = [line for line in lines if line.startswith(("Metric: ", "Caption: "))]
    context_metric = None
    context_k = None
    context_quote = ""
    for line in context_lines:
        m, k = _metric_spec(line)
        if m is not None:
            if context_metric is not None and (context_metric, context_k) != (m, k):
                context_metric = None
                break
            context_metric, context_k, context_quote = m, k, line
    rows: list[dict[str, Any]] = []
    skipped = 0
    def note(reason: str, row: str, *, column: int | None = None) -> None:
        if diagnostics is not None and len(diagnostics) < 100:
            diagnostics.append({"fragment_id": str(frag.id), "page": frag.page,
                                "reason": reason, "source_row": row[:500],
                                "column_index": column})
    for row_line in lines:
        if not row_line.startswith("Row: "):
            continue
        cells = [x.strip() for x in row_line.removeprefix("Row: ").split("|")]
        if len(cells) != len(headers):
            skipped += 1
            note("column_count_mismatch", row_line)
            continue
        if system_col is not None and not cells[system_col]:
            skipped += 1
            note("missing_system", row_line, column=system_col)
            continue
        if dataset_col is not None and not cells[dataset_col]:
            skipped += 1
            note("missing_dataset", row_line, column=dataset_col)
            continue
        for col, raw in enumerate(cells):
            if col == system_col or col == dataset_col:
                continue
            number = _NUM.fullmatch(raw)
            if number is None:
                continue
            value = float(number.group(1).replace(",", "."))
            # Numeric headers like "Time (ms)" must not masquerade as RAG metrics.
            head_metric, head_k = _metric_spec(headers[col])
            metric = head_metric or context_metric
            k = head_k if head_metric else context_k
            if system_col is not None and dataset_col is not None:
                system = cells[system_col]
                dataset = cells[dataset_col]
                dataset_quote = row_line
                system_quote = row_line
            elif system_col is not None:
                system = cells[system_col]
                dataset = _dataset_from_heading(headers[col])
                dataset_quote = header_quote
                system_quote = row_line
                # A dataset column without an explicit metric must remain incomplete,
                # never label numeric values as Exact Match by assumption.
            else:
                dataset = cells[dataset_col]
                system = _system_from_heading(headers[col])
                dataset_quote = row_line
                system_quote = header_quote
            if metric is None or not system or not dataset:
                skipped += 1
                missing = ("metric" if metric is None else
                           "system" if not system else "dataset")
                note("missing_" + missing + "_context", row_line, column=col)
                continue
            # Header must support metric, unless explicit caption/metric line does.
            metric_quote = header_quote if head_metric else context_quote
            record: dict[str, Any] = {
                "rag_variant": system,
                "dataset_name": dataset,
                "metric_name": metric,
                "metric_value": value,
                "evidence": [
                    _evidence("rag_variant", frag, system_quote),
                    _evidence("dataset_name", frag, dataset_quote),
                    _evidence("metric_name", frag, metric_quote),
                    _evidence("metric_value", frag, row_line),
                ],
            }
            # A 3-axis PDF table can explicitly name the generator per column.
            # No model is inferred if this exact marker is absent in the header.
            generator = re.search(r"\[generator=([A-Za-z0-9][A-Za-z0-9._+ \-]{1,70})\]", headers[col])
            if generator:
                record["generator_model"] = generator.group(1)
                record["evidence"].append(_evidence("generator_model", frag, header_quote))
            if k is not None:
                record["metric_k"] = k
                record["evidence"].append(_evidence("metric_k", frag, metric_quote))
            # Preserve published numeric scale. Percent only when literally given.
            if number.group(2) or "%" in headers[col]:
                record["metric_unit"] = "percent"
                record["evidence"].append(_evidence("metric_unit", frag, row_line if number.group(2) else header_quote))
            # Preserve the physical page/table identity; equality of metric alone
            # never establishes that two different tables describe one experiment.
            record["_table_identity"] = (
                frag.page,
                re.sub(r"\s+", " ", header_quote).casefold(),
                next((re.sub(r"\s+", " ", x).casefold()
                      for x in lines if x.startswith("Caption: ")), ""),
            )
            rows.append(record)
            if len(rows) >= _MAX_RECORDS:
                return rows, skipped
    return rows, skipped


def _logical_key(record: dict[str, Any]) -> tuple:
    """Same physical table, method, dataset, metric and generator = one cell."""
    return (
        record["_table_identity"],
        str(record["rag_variant"]).strip().casefold(),
        str(record["dataset_name"]).strip().casefold(),
        str(record["metric_name"]).strip().casefold(),
        record.get("metric_k"),
        str(record.get("generator_model") or "").strip().casefold(),
    )


def _merge_evidence(target: dict[str, Any], incoming: dict[str, Any]) -> None:
    """Retain citations from distinct source fragments without unbounded payloads."""
    old = target["evidence"]
    seen = {(e["field"], e["fragment_id"], e["quote"]) for e in old}
    counts: dict[str, int] = {}
    for e in old:
        counts[e["field"]] = counts.get(e["field"], 0) + 1
    for e in incoming["evidence"]:
        signature = (e["field"], e["fragment_id"], e["quote"])
        if signature not in seen and counts.get(e["field"], 0) < 3:
            old.append(e)
            seen.add(signature)
            counts[e["field"]] = counts.get(e["field"], 0) + 1


def extract_rag_table_records(fragments: Iterable[SourceFragment], limit: int = _MAX_RECORDS) -> TableExtraction:
    """Deduplicate before limiting; quarantine contradictory values, no persistence."""
    table_count = skipped_rows = duplicate_count = 0
    skipped_details: list[dict[str, Any]] = []
    accepted: dict[tuple, dict[str, Any]] = {}
    conflicts: set[tuple] = set()
    # We scan all available fragments, even when an earlier group would fill
    # the response limit. Otherwise later duplicates/contradictions go unseen.
    for frag in fragments:
        if not frag.text.startswith("EXTRACTED TABLE ("):
            continue
        table_count += 1
        if table_count > _MAX_TABLE_FRAGMENTS:
            break
        rows, skipped = _parse_one(frag, skipped_details)
        skipped_rows += skipped
        for row in rows:
            key = _logical_key(row)
            if key in conflicts:
                continue
            existing = accepted.get(key)
            if existing is None:
                accepted[key] = row
                continue
            same_value = existing["metric_value"] == row["metric_value"]
            same_unit = existing.get("metric_unit") == row.get("metric_unit")
            if not (same_value and same_unit):
                # Never silently pick either of two contradictory source cells.
                accepted.pop(key, None)
                conflicts.add(key)
                continue
            duplicate_count += 1
            _merge_evidence(existing, row)
    selected = list(accepted.values())[:max(1, min(limit, _MAX_RECORDS))]
    for item in selected:
        item.pop("_table_identity", None)
    return TableExtraction(
        records=selected,
        table_fragment_count=min(table_count, _MAX_TABLE_FRAGMENTS),
        skipped_rows=skipped_rows,
        complete_context_count=len(selected),
        duplicate_count=duplicate_count,
        conflicting_groups=len(conflicts),
        skipped_details=tuple(skipped_details),
    )
