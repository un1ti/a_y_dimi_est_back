"""v3.2 source-PDF layout evidence, no claim validation or numeric certification.

Read a stored uploaded PDF, selecting spatially coherent text blocks rather than
flattened two-column page strings. All excerpts are literal PDF block substrings.
Missing/mismatched sources fail closed, never reverting to unverifiable quotes.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import re

import pymupdf
from app.services.rag_semantic_v31 import TOPICS, COMPILED


def _lines_from_block(text: str):
    """Preserve a PDF block's line geometry: never join unrelated columns."""
    for raw in text.splitlines():
        line = ' '.join(raw.split())
        if not 28 <= len(line) <= 250:
            continue
        if line.startswith(('Row:', 'Columns:', 'EXTRACTED TABLE', 'http')):
            continue
        if line.count(' | ') > 1 or '\ufffd' in line:
            continue
        # Extraction of visually overlapping diagram text is not a reliable
        # source quotation. Also reject obvious run-together or mixed text.
        if re.search(r'\w{35,}', line):
            continue
        yield line


def pdf_topic_evidence(pdf_path: Path, expected_sha256: str, *, per_topic: int = 3) -> dict:
    if not 1 <= per_topic <= 10:
        raise ValueError('per_topic must be in 1..10')
    path = Path(pdf_path)
    empty = {key: [] for key in TOPICS}
    if not path.is_file():
        return {'source_status': 'pdf_unavailable', 'topics': empty, 'rejected_lines': 0}
    if not re.fullmatch(r'[0-9a-f]{64}', str(expected_sha256 or ''), re.I):
        return {'source_status': 'invalid_expected_checksum', 'topics': empty, 'rejected_lines': 0}
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256.lower():
        return {'source_status': 'pdf_checksum_mismatch', 'topics': empty, 'rejected_lines': 0}
    seen: set[tuple] = set()
    total_rejected = 0
    evidence = {key: [] for key in TOPICS}
    try:
        with pymupdf.open(path) as doc:
            if doc.needs_pass:
                return {'source_status': 'pdf_encrypted', 'topics': empty, 'rejected_lines': 0}
            for page_n, page in enumerate(doc, 1):
                width = float(page.rect.width)
                for block in page.get_text('dict', sort=True).get('blocks', []):
                    if block.get('type') != 0:
                        continue
                    for line_data in block.get('lines', []):
                        raw = ''.join(span.get('text', '') for span in line_data.get('spans', []))
                        box = line_data.get('bbox', block.get('bbox'))
                        if not box: continue
                        x0, y0, x1, y1 = box
                        # Reject suspicious full-width body text, e.g. two
                        # interleaved columns in one physical line.
                        if (x1-x0)>width*0.72 and y0 > page.rect.height*0.18:
                            total_rejected += 1
                            continue
                        for line in _lines_from_block(raw):
                            if not any(p.search(line) for patterns in COMPILED.values() for p in patterns):
                                continue
                            partial = bool(line.endswith('-') or re.search(r'\b(?:and|the|of|for|with|to|in)\s*$', line, re.I))
                            for topic, patterns in COMPILED.items():
                                if len(evidence[topic]) >= per_topic or not any(p.search(line) for p in patterns):
                                    continue
                                key = (topic, page_n, line.casefold())
                                if key in seen: continue
                                seen.add(key)
                                evidence[topic].append({
                                    'page': page_n, 'quote': line,
                                    'bbox': [round(float(v), 2) for v in (x0,y0,x1,y1)],
                                    'source': 'original_pdf_text_line',
                                    'source_checksum_verified': True,
                                    'quote_verified_in_block': line == ' '.join(raw.split()),
                                    'quality': 'partial_line' if partial else 'layout_checked',
                                    'confidence': 'low' if partial else 'medium',
                                    'status': 'candidate_requires_review',
                                })
    except (OSError, RuntimeError, ValueError, pymupdf.FileDataError):
        return {'source_status': 'pdf_read_error', 'topics': empty, 'rejected_lines': total_rejected}
    return {'source_status': 'checksum_verified', 'topics': evidence, 'rejected_lines': total_rejected}


def quality_compare(left_pdf: Path, left_hash: str, right_pdf: Path, right_hash: str, *, per_topic: int = 3) -> dict:
    a = pdf_topic_evidence(left_pdf, left_hash, per_topic=per_topic)
    b = pdf_topic_evidence(right_pdf, right_hash, per_topic=per_topic)
    shared, left_only, right_only = [], [], []
    for topic, (label, _) in TOPICS.items():
        aa, bb = a['topics'][topic], b['topics'][topic]
        if not aa and not bb: continue
        obj = {'topic': topic, 'label': label, 'left_evidence': aa, 'right_evidence': bb,
               'interpretation': 'topic_candidate_only_not_method_equivalence'}
        (shared if aa and bb else left_only if aa else right_only).append(obj)
    cards = [{'claim': f'Both documents mention: {item["label"]}',
              'claim_status': 'topic_match_only',
              'left_evidence': item['left_evidence'],
              'right_evidence': item['right_evidence'],
              'verdict': 'requires_human_review',
              'method_equivalence_verified': False}
             for item in shared]
    return {'source_status': {'left': a['source_status'], 'right': b['source_status']},
            'comparison_cards': cards,
            'shared_topic_count': len(shared), 'left_only_topic_count': len(left_only),
            'right_only_topic_count': len(right_only),
            'shared_topics': shared, 'left_only_topics': left_only, 'right_only_topics': right_only,
            'rejected_blocks': {'left': a['rejected_lines'], 'right': b['rejected_lines']},
            'method_equivalence_verified': False, 'scientific_superiority_verdict': 'insufficient_data',
            'evidence_status': 'candidate_requires_review',
            'limitations': ['Text lines are layout-checked, not scientifically fact-checked.',
                            'Coordinates are extracted PDF line bounds, not independent word bounds.',
                            'Headings and diagrams may still cause irrelevant keyword matches.',
                            'Missing topics do not imply their absence in a paper.']}
