"""V3.0: read-only, source-grounded experiment context hints and file-level comparison.

No source text is promoted to certified per-row metadata automatically.
"""
from __future__ import annotations
from collections import Counter, defaultdict
import re
from typing import Any

# A contextual keyword is an investigative hint, never proof that a particular
# numeric result was evaluated at that stage.
STAGE_PATTERNS = {
    'embedding': re.compile(r'\b(?:embedding|embedder|text-embedding|bge-large)\b', re.I),
    'reranking': re.compile(r'\b(?:rerank(?:er|ing)?|cross-encoder)\b', re.I),
    'retrieval': re.compile(r'\b(?:retriev(?:al|er)|recall@|top[- ]?k)\b', re.I),
    'generation': re.compile(r'\b(?:generation|generator|answer generation|language model)\b', re.I),
}
CONTEXT_PATTERNS = {
    'evaluation_protocol': re.compile(r'\b(?:evaluat(?:ion|ed|ing)|benchmark|experimental setup|experimental settings|protocol|we measure|measured using)\b', re.I),
    'split': re.compile(r'\b(?:train(?:ing)?|validation|dev(?:elopment)?|test)\s+(?:set|split|dataset|partition)\b|\b(?:split|partition)(?:s|ted)?\b', re.I),
    'evaluation_stage': re.compile(r'\b(?:embedding|rerank(?:er|ing)?|retriev(?:al|er)|generat(?:ion|or)|end[- ]to[- ]end)\b', re.I),
}


def _text_lines(raw: str) -> list[str]:
    lines = []
    for line in raw.splitlines():
        clean = ' '.join(line.split())
        if 20 <= len(clean) <= 500 and not clean.startswith(('Row:', 'Columns:')):
            lines.append(clean)
    return lines


def collect_evidence(fragments: list[Any], *, max_per_field: int = 12) -> dict:
    """Retrieve bounded literal quotes; do not invent stage, protocol or split."""
    found: dict[str, list[dict]] = {key: [] for key in CONTEXT_PATTERNS}
    seen = set()
    for fragment in fragments:
        # EXTRACTED TABLE fragments hold reconstructed tabular values, not
        # reliable prose about experimental protocol.
        if str(fragment.text).startswith('EXTRACTED TABLE ('):
            continue
        for line in _text_lines(str(fragment.text)):
            for field, pattern in CONTEXT_PATTERNS.items():
                if len(found[field]) >= max_per_field or not pattern.search(line):
                    continue
                token = (field, fragment.page, line.casefold())
                if token in seen:
                    continue
                seen.add(token)
                found[field].append({'page': fragment.page, 'fragment_id': fragment.id,
                                     'quote': line[:500], 'status': 'candidate_requires_review'})
    return {'candidates': found,
            'verified_context': {'evaluation_stage': None, 'evaluation_protocol': None, 'split': None},
            'verification_status': 'not_verified',
            'note': 'Quoted sentences are candidates only; they are not automatically attached to results or treated as verified experimental conditions.'}


def stage_hint(row: dict) -> dict:
    """Return a non-authoritative row-label hint, never a verified evaluation stage."""
    label = str(row.get('system') or '')
    hits = [stage for stage, pattern in STAGE_PATTERNS.items() if pattern.search(label)]
    # A generic retrieval keyword on a reranker name is not strong evidence.
    stage = hits[0] if len(hits) == 1 else None
    return {'stage_hint': stage, 'stage_verified': False,
            'hint_basis': 'system_label_only' if stage else 'unknown'}


def enriched_audit(rows: list[dict]) -> dict:
    from app.services.rag_comparison_v29 import audit_preview
    result = audit_preview(rows)
    for family in result['families']:
        subset = [r for r in rows if (r.get('dataset'), r.get('metric'), r.get('metric_k')) ==
                  (family['dataset'], family['metric'], family['metric_k'])]
        hints = Counter(stage_hint(r)['stage_hint'] or 'unknown' for r in subset)
        family['unverified_stage_hints'] = dict(sorted(hints.items()))
        family['mixed_stage_hints'] = len([h for h in hints if h != 'unknown']) > 1
        family['readiness'] = 'insufficient_data'
    result['note'] += ' Stage hints are speculative and never certify comparability.'
    return result


def _family(r: dict) -> tuple:
    return (str(r.get('dataset') or '').strip().casefold(),
            str(r.get('metric') or '').strip().casefold(), r.get('metric_k'))


def _row_key(r: dict) -> tuple:
    return (_family(r), str(r.get('system') or '').strip().casefold(),
            str(r.get('generator_model') or '').strip().casefold())


def compare_documents(left: list[dict], right: list[dict], *, max_examples: int = 35) -> dict:
    """Summarize two stored document previews. No cross-paper comparability certified.

    Value differences are NOT labeled contradictions: methods or protocols may differ.
    """
    left_families = defaultdict(list)
    right_families = defaultdict(list)
    for r in left: left_families[_family(r)].append(r)
    for r in right: right_families[_family(r)].append(r)
    shared = sorted(left_families.keys() & right_families.keys(), key=str)
    left_only = sorted(left_families.keys() - right_families.keys(), key=str)
    right_only = sorted(right_families.keys() - left_families.keys(), key=str)
    left_keys = defaultdict(list)
    right_keys = defaultdict(list)
    for r in left: left_keys[_row_key(r)].append(r)
    for r in right: right_keys[_row_key(r)].append(r)
    matching_keys = left_keys.keys() & right_keys.keys()
    differences = []
    identical = 0
    ambiguous = 0
    for key in sorted(matching_keys, key=str):
        a, b = left_keys[key], right_keys[key]
        # Duplicate canonical keys with different values are not resolved arbitrarily.
        if len(a) != 1 or len(b) != 1:
            ambiguous += 1
            continue
        if a[0].get('value') == b[0].get('value'):
            identical += 1
        else:
            differences.append({'dataset': a[0].get('dataset'), 'metric': a[0].get('metric'),
                                'metric_k': a[0].get('metric_k'), 'system': a[0].get('system'),
                                'generator_model': a[0].get('generator_model'),
                                'left_value': a[0].get('value'), 'right_value': b[0].get('value'),
                                'left_source': {'page': a[0].get('source_page'), 'fragment_id': a[0].get('fragment_id')},
                                'right_source': {'page': b[0].get('source_page'), 'fragment_id': b[0].get('fragment_id')},
                                'status': 'reported_value_difference_not_certified_contradiction'})
    def family_view(keys, d1, d2=None):
        return [{'dataset': k[0], 'metric': k[1], 'metric_k': k[2],
                 'left_count': len(d1[k]), 'right_count': len(d2[k]) if d2 is not None else 0}
                for k in keys]
    return {'left_record_count': len(left), 'right_record_count': len(right),
            'shared_family_count': len(shared), 'left_only_family_count': len(left_only),
            'right_only_family_count': len(right_only),
            'shared_families': family_view(shared, left_families, right_families),
            'left_only_families': family_view(left_only, left_families),
            'right_only_families': family_view(right_only, left_families, right_families),
            'same_system_metric_pairs': len(matching_keys),
            'same_reported_value_pairs': identical,
            'reported_value_difference_count': len(differences),
            'ambiguous_key_pairs': ambiguous,
            'reported_value_difference_examples': differences[:max_examples],
            'overall_verdict': 'insufficient_data',
            'missing_for_certified_comparison': ['evaluation_stage', 'evaluation_protocol', 'split', 'evaluation_scope'],
            'note': 'Shared metric families are discovery matches, not comparable experiments. Numerical differences are not scientific contradictions without verified same evaluation conditions. Read-only.'}
