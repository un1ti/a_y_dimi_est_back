"""Read-only scientific comparison audit for RAG table previews (v2.9)."""
from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.api.rag_table_routes import rag_table_preview
from app.services.rag_comparison_v29 import audit_preview, compare_previews

router = APIRouter(prefix='/api/v1/scientific/rag', tags=['RAG Comparability v2.9'])

class PreviewRow(BaseModel):
    system: str | None = None
    dataset: str | None = None
    metric: str | None = None
    metric_k: int | None = None
    value: float | None = None
    source_page: int | None = None
    fragment_id: str | None = None
    generator_model: str | None = None
    evaluation_stage: str | None = None
    evaluation_protocol: str | None = None
    evaluation_scope: str | None = None
    split: str | None = None
    metric_unit: str | None = None
    aggregation: str | None = None

class ComparisonRequest(BaseModel):
    left: PreviewRow
    right: PreviewRow

@router.post('/compare-preview')
def compare_preview(payload: ComparisonRequest):
    return compare_previews(payload.left.model_dump(), payload.right.model_dump())

@router.get('/comparison-audit')
def comparison_audit(publication_id: str, request: Request,
                     limit: int = Query(default=600, ge=1, le=600),
                     db: Session = Depends(get_db)):
    preview = rag_table_preview(publication_id=publication_id, request=request, limit=limit, db=db)
    return {'publication_id': publication_id,
            'candidate_count': preview['candidate_count'],
            'complete_context_count': preview['complete_context_count'],
            'duplicate_count': preview['deduplicated_repeat_count'],
            'conflict_count': preview['conflicting_groups_skipped'],
            'audit': audit_preview(preview['records'])}
