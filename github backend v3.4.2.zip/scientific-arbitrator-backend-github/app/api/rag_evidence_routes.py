"""Scientific Arbitrator 3.0: read-only provenance and file-to-file RAG review."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from pathlib import Path
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.models import Publication, SourceFragment
from app.db.session import get_db
from app.api.rag_table_routes import rag_table_preview
from app.services.rag_evidence_v30 import collect_evidence, enriched_audit, compare_documents
from app.services.rag_semantic_v31 import semantic_compare
from app.services.rag_evidence_quality_v32 import quality_compare
from app.services.rag_claim_explainer_v33 import (
    pdf_explanation_evidence, build_context, generate_explanation, ExplanationError,
)

router = APIRouter(prefix='/api/v1/scientific/rag', tags=['RAG Evidence and File Comparison v3.0'])


def _doc(db: Session, pub_id: str) -> Publication:
    doc = db.get(Publication, pub_id)
    if doc is None or doc.domain != 'rag':
        raise HTTPException(404, 'RAG publication not found')
    return doc


def _fragments(db: Session, pub_id: str):
    return db.scalars(select(SourceFragment).where(SourceFragment.publication_id == pub_id)
                      .order_by(SourceFragment.page, SourceFragment.position)).all()


@router.get('/evidence-audit')
def evidence_audit(publication_id: str, request: Request,
                   limit: int = Query(600, ge=1, le=600), db: Session = Depends(get_db)):
    doc = _doc(db, publication_id)
    rows = rag_table_preview(publication_id=publication_id, request=request, limit=limit, db=db)
    return {'publication_id': doc.id, 'filename': doc.filename,
            'preview_record_count': len(rows['records']),
            'table_issues': {'skipped_details': rows.get('skipped_details', []),
                             'duplicates_removed': rows.get('deduplicated_repeat_count', 0),
                             'conflicting_groups_skipped': rows.get('conflicting_groups_skipped', 0)},
            'context_evidence': collect_evidence(_fragments(db, doc.id)),
            'audit': enriched_audit(rows['records'])}


@router.get('/compare-documents')
def compare_rag_documents(left_publication_id: str, right_publication_id: str,
                          request: Request, limit: int = Query(600, ge=1, le=600),
                          db: Session = Depends(get_db)):
    a, b = _doc(db, left_publication_id), _doc(db, right_publication_id)
    if a.id == b.id:
        raise HTTPException(422, 'Choose two different publications')
    ap = rag_table_preview(publication_id=a.id, request=request, limit=limit, db=db)
    bp = rag_table_preview(publication_id=b.id, request=request, limit=limit, db=db)
    analysis = compare_documents(ap['records'], bp['records'])
    return {'left_document': {'publication_id': a.id, 'filename': a.filename, 'sha256': a.sha256},
            'right_document': {'publication_id': b.id, 'filename': b.filename, 'sha256': b.sha256},
            'preview_limit': limit,
            'left_preview': {'count': len(ap['records']), 'skipped': ap.get('skipped_cells_or_rows', 0),
                             'conflicts': ap.get('conflicting_groups_skipped', 0)},
            'right_preview': {'count': len(bp['records']), 'skipped': bp.get('skipped_cells_or_rows', 0),
                              'conflicts': bp.get('conflicting_groups_skipped', 0)},
            'comparison': analysis,
            'left_evidence': collect_evidence(_fragments(db, a.id)),
            'right_evidence': collect_evidence(_fragments(db, b.id))}


@router.get('/semantic-compare-documents')
def semantic_compare_rag_documents(left_publication_id: str, right_publication_id: str,
                                   per_topic: int = Query(3, ge=1, le=10),
                                   db: Session = Depends(get_db)):
    """Fast read-only thematic comparison: no numeric table re-extraction."""
    a, b = _doc(db, left_publication_id), _doc(db, right_publication_id)
    if a.id == b.id:
        raise HTTPException(422, 'Choose two different publications')
    analysis = semantic_compare(_fragments(db, a.id), _fragments(db, b.id), per_topic=per_topic)
    return {'left_document': {'publication_id': a.id, 'filename': a.filename, 'sha256': a.sha256},
            'right_document': {'publication_id': b.id, 'filename': b.filename, 'sha256': b.sha256},
            'semantic_comparison': analysis,
            'quantitative_comparison': {'endpoint': '/api/v1/scientific/rag/compare-documents',
                                       'status': 'not_run',
                                       'note': 'Numeric comparison is a separate read-only operation.'}}


@router.get('/research-compare')
def research_compare_rag_documents(left_publication_id: str, right_publication_id: str,
                                  request: Request, limit: int = Query(600, ge=1, le=600),
                                  per_topic: int = Query(3, ge=1, le=10),
                                  db: Session = Depends(get_db)):
    """Combined evidence and numeric report with independent verdicts."""
    a, b = _doc(db, left_publication_id), _doc(db, right_publication_id)
    if a.id == b.id:
        raise HTTPException(422, 'Choose two different publications')
    numeric = compare_rag_documents(left_publication_id=a.id, right_publication_id=b.id,
                                    request=request, limit=limit, db=db)
    numeric['semantic_comparison'] = semantic_compare(
        _fragments(db, a.id), _fragments(db, b.id), per_topic=per_topic)
    numeric['report_version'] = '3.1'
    numeric['report_status'] = 'exploratory_requires_review'
    return numeric


@router.get('/quality-compare-documents')
def quality_compare_rag_documents(left_publication_id: str, right_publication_id: str,
                                  request: Request, per_topic: int = Query(3, ge=1, le=10),
                                  db: Session = Depends(get_db)):
    """Spatial PDF-block evidence, checksum verified; still exploratory."""
    a, b = _doc(db, left_publication_id), _doc(db, right_publication_id)
    if a.id == b.id:
        raise HTTPException(422, 'Choose two different publications')
    # Old SQLite stored_path values are relative to DATA_DIR, not to process cwd.
    # Resolve via the trusted storage layout and immutable publication IDs.
    analysis = quality_compare(
        request.app.state.settings.data_dir / "uploads" / f"{a.id}.pdf", a.sha256,
        request.app.state.settings.data_dir / "uploads" / f"{b.id}.pdf", b.sha256,
        per_topic=per_topic)
    return {'left_document': {'publication_id': a.id, 'filename': a.filename},
            'right_document': {'publication_id': b.id, 'filename': b.filename},
            'evidence_comparison': analysis, 'report_version': '3.2',
            'report_status': 'exploratory_requires_review'}


class ExplainComparisonRequest(BaseModel):
    left_publication_id: str = Field(min_length=36, max_length=36)
    right_publication_id: str = Field(min_length=36, max_length=36)
    language: str = Field(default='ru', pattern='^(ru|en)$')
    focus: str | None = Field(default=None, max_length=300)
    per_topic: int = Field(default=2, ge=1, le=4)
    include_numeric_summary: bool = False


@router.post('/explain-comparison-v34')
@router.post('/explain-comparison')
def explain_rag_documents(body: ExplainComparisonRequest, request: Request,
                          db: Session = Depends(get_db)):
    """LLM-generated, source-cited explanatory *draft*, never a certified scientific verdict.

    Requires LLM_MODE=openai and an Ollama/OpenAI-compatible endpoint. Calls
    only the configured provider. Does not write the database or alter PDFs.
    """
    left = _doc(db, body.left_publication_id)
    right = _doc(db, body.right_publication_id)
    if left.id == right.id:
        raise HTTPException(422, 'Choose two different publications')
    settings = request.app.state.settings
    left_ev = pdf_explanation_evidence(settings.data_dir / 'uploads' / f'{left.id}.pdf',
                                      left.sha256, side='L', per_topic=body.per_topic,
                                      max_pages=settings.max_pdf_pages)
    right_ev = pdf_explanation_evidence(settings.data_dir / 'uploads' / f'{right.id}.pdf',
                                       right.sha256, side='R', per_topic=body.per_topic,
                                       max_pages=settings.max_pdf_pages)
    statuses = {'left': left_ev['source_status'], 'right': right_ev['source_status']}
    if statuses['left'] != 'checksum_verified' or statuses['right'] != 'checksum_verified':
        raise HTTPException(status_code=409,
                            detail={'message': 'Both original PDFs must be accessible and checksum verified',
                                    'source_status': statuses})
    _, catalog = build_context(left_ev, right_ev, max_chars=settings.max_prompt_chars - 2800)
    numeric_summary = None
    numeric_context = None
    if body.include_numeric_summary:
        # Optional: an independent, read-only table preview. This can be slow
        # for complex PDFs, so the normal explanation does not wait for it.
        a_rows = rag_table_preview(publication_id=left.id, request=request, limit=600, db=db)
        b_rows = rag_table_preview(publication_id=right.id, request=request, limit=600, db=db)
        audit = compare_documents(a_rows['records'], b_rows['records'])
        numeric_summary = {
            'status': 'uncertified_table_preview',
            'left_record_count': audit['left_record_count'],
            'right_record_count': audit['right_record_count'],
            'shared_family_count': audit['shared_family_count'],
            'left_only_family_count': audit['left_only_family_count'],
            'right_only_family_count': audit['right_only_family_count'],
            'overall_verdict': audit['overall_verdict'],
            'missing_for_certified_comparison': audit['missing_for_certified_comparison'],
            'shared_families': audit['shared_families'][:8],
        }
        numeric_context = {k: v for k, v in numeric_summary.items() if k != 'missing_for_certified_comparison'}
    try:
        explanation = generate_explanation(settings, left_ev, right_ev,
                                           language=body.language, focus=body.focus,
                                           numeric_context=numeric_context)
    except ExplanationError as exc:
        raise HTTPException(status_code=503 if 'LLM' in str(exc) or 'model' in str(exc) else 502,
                            detail=str(exc)) from exc
    return {
        'left_document': {'publication_id': left.id, 'filename': left.filename},
        'right_document': {'publication_id': right.id, 'filename': right.filename},
        'source_status': statuses, 'model': settings.llm_model,
        'evidence_catalog': catalog, 'explanation': explanation,
        'numeric_summary': numeric_summary,
        'report_version': ('3.4' if request.url.path.endswith('-v34') else '3.3'),
        'report_status': 'exploratory_requires_review',
        'explanation_type': 'llm_grounded_interpretation_not_certified',
    }


@router.get('/demo-v34', response_class=HTMLResponse, include_in_schema=False)
def scientific_comparison_demo_v34():
    """Small no-build, same-origin demonstration UI for a hackathon."""
    return HTMLResponse((Path(__file__).parent / 'rag_demo_v34.html').read_text(encoding='utf-8'))


@router.get('/demo-fixture-v34', include_in_schema=False)
def scientific_comparison_fixture_v34():
    """Historical demo data, never a live analysis or certified scientific verdict."""
    import json
    fixture = Path(__file__).parent / 'rag_demo_fixture_v34.json'
    return json.loads(fixture.read_text(encoding='utf-8'))
