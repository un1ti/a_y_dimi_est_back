from types import SimpleNamespace
from app.services.rag_semantic_v31 import topic_evidence, semantic_compare


def frag(fid, page, text):
    return SimpleNamespace(id=fid, page=page, text=text)


def test_shared_topic_has_two_literal_source_links():
    left=[frag('l1',1,'We use a dense embedding model for retrieving relevant documentation.')]
    right=[frag('r1',6,'Our embedding representations support retrieval of matching documents.')]
    result=semantic_compare(left,right)
    entry=next(t for t in result['shared_topics'] if t['topic']=='embedding')
    assert entry['left_evidence'][0]['fragment_id']=='l1'
    assert entry['right_evidence'][0]['page']==6
    assert not result['method_equivalence_verified']
    assert result['scientific_superiority_verdict']=='insufficient_data'


def test_nonoverlap_not_misrepresented_as_contradiction():
    a=[frag('a',2,'Documentation QA system uses embedding models for matching documents.')]
    b=[frag('b',5,'Graph-based multi-hop reasoning operates over a knowledge graph.')]
    r=semantic_compare(a,b)
    assert r['shared_topic_count']==0
    assert r['left_only_topic_count']>0 and r['right_only_topic_count']>0
    assert r['scientific_superiority_verdict']=='insufficient_data'


def test_source_table_and_duplicate_lines_are_ignored():
    frags=[frag('table',2,'EXTRACTED TABLE (x)\nRow: Embedding | 0.2'),
           frag('a',3,'The retrieval mechanism uses a dense embedding representation.'),
           frag('b',3,'The retrieval mechanism uses a dense embedding representation.')]
    found=topic_evidence(frags)
    assert len(found['embedding'])==1
    assert found['embedding'][0]['fragment_id']=='a'


def test_bounded_evidence_and_bad_parameters():
    items=[frag(str(i),i,'This document uses a retrieval system to find evidence relevant to questions.') for i in range(25)]
    assert len(topic_evidence(items,per_topic=2)['retrieval'])==2
    import pytest
    with pytest.raises(ValueError): topic_evidence(items,per_topic=0)


def test_api_missing_document_and_same_doc(client):
    params={'left_publication_id':'missing','right_publication_id':'also-missing'}
    assert client.get('/api/v1/scientific/rag/semantic-compare-documents',params=params).status_code==404
    assert client.get('/api/v1/scientific/rag/research-compare',params=params).status_code==404


def test_api_schema_contains_v31_endpoints(client):
    schema=client.get('/openapi.json').json()['paths']
    assert '/api/v1/scientific/rag/semantic-compare-documents' in schema
    assert '/api/v1/scientific/rag/research-compare' in schema
