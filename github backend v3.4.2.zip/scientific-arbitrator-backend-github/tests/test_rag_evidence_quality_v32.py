from pathlib import Path
import hashlib
import pymupdf
from app.services.rag_evidence_quality_v32 import pdf_topic_evidence, quality_compare
from app.services.rag_evidence_v30 import compare_documents


def sample_pdf(path):
    with pymupdf.open() as doc:
        page=doc.new_page(width=600, height=800)
        page.insert_text((55, 200), 'The retrieval system uses dense embeddings for document search.', fontsize=10)
        page.insert_text((320, 200), 'The graph architecture supports multi-hop reasoning tasks.', fontsize=10)
        doc.save(path)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_right_only_count_regression():
    left=[{'dataset':'ord', 'metric':'BLEU', 'system':'a', 'value':.5}]
    right=[{'dataset':'hotpotqa', 'metric':'F1', 'system':'b', 'value':.7}]
    got=compare_documents(left,right)
    assert got['right_only_families'][0]['left_count']==0
    assert got['right_only_families'][0]['right_count']==1
    assert got['left_only_families'][0]['left_count']==1
    assert got['left_only_families'][0]['right_count']==0


def test_pdf_layout_evidence_checksum_and_coordinates(tmp_path):
    p=tmp_path/'x.pdf'; digest=sample_pdf(p)
    out=pdf_topic_evidence(p,digest)
    assert out['source_status']=='checksum_verified'
    found=out['topics']['retrieval']
    assert found and found[0]['page']==1
    assert found[0]['source_checksum_verified'] and found[0]['quote_verified_in_block']
    assert len(found[0]['bbox'])==4
    assert found[0]['status']=='candidate_requires_review'


def test_missing_or_altered_pdf_fails_closed(tmp_path):
    p=tmp_path/'x.pdf'; digest=sample_pdf(p)
    assert pdf_topic_evidence(p,'0'*64)['source_status']=='pdf_checksum_mismatch'
    assert not pdf_topic_evidence(p,'0'*64)['topics']['retrieval']
    assert pdf_topic_evidence(tmp_path/'missing.pdf',digest)['source_status']=='pdf_unavailable'


def test_quality_compare_not_certification(tmp_path):
    p=tmp_path/'x.pdf'; sha=sample_pdf(p)
    r=quality_compare(p,sha,p,sha)
    assert r['shared_topic_count'] >= 1
    assert r['method_equivalence_verified'] is False
    assert r['scientific_superiority_verdict']=='insufficient_data'


def test_api_schema_v32(client):
    assert '/api/v1/scientific/rag/quality-compare-documents' in client.get('/openapi.json').json()['paths']
    assert client.get('/api/v1/scientific/rag/quality-compare-documents',params={'left_publication_id':'a','right_publication_id':'b'}).status_code==404
