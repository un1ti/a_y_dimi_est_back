"""v3.3 tests: real PDF geometry, strict citations, app contract and fail-closed paths."""
import hashlib
import json
from uuid import uuid4

import pymupdf
from fastapi.testclient import TestClient

from app.config import Settings
from app.db.models import Publication
from app.main import create_app
import app.services.rag_claim_explainer_v33 as v33


def make_pdf(path, *lines):
    with pymupdf.open() as doc:
        page = doc.new_page(width=640, height=800)
        for idx, line in enumerate(lines):
            page.insert_text((60, 150 + idx * 20), line, fontsize=11)
        doc.save(path)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def model_reply(**kwargs):
    return json.dumps({'summary': 'Обе работы используют поиск, но цитаты показывают разные детали.',
         'comparisons': [{
              'topic': 'retrieval',
              'left_method': 'The paper studies dense retrieval.',
              'right_method': 'The paper evaluates retrieval with reranking.',
              'similarity': 'Both mention retrieval.',
              'difference': 'Reranking is mentioned by the right paper.',
              'left_advantage': 'Not established by cited excerpts.',
              'right_advantage': 'Not established by cited excerpts.',
              'relationship': 'potential_method_difference',
              'left_evidence_ids': ['L-retrieval-1'],
              'right_evidence_ids': kwargs.get('right_ids', ['R-retrieval-1']),
              'uncertainty': 'No experimental equivalence verified.',
         }], 'limitations': ['Cannot rank performance without matched metrics.']})


def test_geometry_and_checksum_fail_closed(tmp_path):
    path = tmp_path / 'x.pdf'
    sha = make_pdf(path, 'We use dense retrieval and embedding for passages.',
                   'Our retrieval pipeline uses a local vector database.',
                   'The model processes a graph to answer questions.')
    obj = v33.pdf_explanation_evidence(path, sha, side='L')
    assert obj['source_status'] == 'checksum_verified'
    evidence = obj['topics']['retrieval']
    assert evidence and evidence[0]['evidence_id'] == 'L-retrieval-1'
    assert evidence[0]['source_checksum_verified']
    assert len(evidence[0]['bbox']) == 4
    assert evidence[0]['status'] == 'candidate_requires_review'
    missing = v33.pdf_explanation_evidence(tmp_path / 'missing.pdf', sha, side='L')
    assert missing['source_status'] == 'pdf_unavailable'
    assert all(not x for x in missing['topics'].values())
    changed = v33.pdf_explanation_evidence(path, '0' * 64, side='L')
    assert changed['source_status'] == 'pdf_checksum_mismatch'
    assert all(not x for x in changed['topics'].values())


def test_validated_citations_and_no_scientific_certification():
    catalog = {
        'L-retrieval-1': {'document': 'L', 'topic': 'retrieval'},
        'R-retrieval-1': {'document': 'R', 'topic': 'retrieval'},
    }
    valid = v33._validated_explanation(json.loads(model_reply()), catalog, language='ru')
    assert len(valid['comparisons']) == 1
    assert valid['comparisons'][0]['scientific_verification'] == 'requires_human_review'
    assert valid['scientific_superiority_verdict'] == 'insufficient_data'
    wrong = v33._validated_explanation(json.loads(model_reply(right_ids=['L-retrieval-1'])), catalog, language='ru')
    assert wrong['comparisons'] == [] and wrong['excluded_model_comparisons'] == 1
    assert wrong['summary'] == ''
    fake = v33._validated_explanation(json.loads(model_reply(right_ids=['R-fake-id'])), catalog, language='ru')
    assert fake['comparisons'] == []


def _app_with_pdfs(tmp_path, mode='openai'):
    settings = Settings(data_dir=tmp_path / 'data', database_url=f"sqlite:///{tmp_path / 'main.sqlite'}",
                        llm_mode=mode, llm_model='qwen3.5:4b')
    app = create_app(settings)
    uploads = settings.data_dir / 'uploads'
    uploads.mkdir(parents=True, exist_ok=True)
    ids = (str(uuid4()), str(uuid4()))
    hashes = [make_pdf(uploads / f'{ids[0]}.pdf',
                       'We use dense retrieval for multi-hop question answering.',
                       'The model retrieves knowledge graph passages for the final answer.'),
              make_pdf(uploads / f'{ids[1]}.pdf',
                       'We evaluate document retrieval using an embedding retriever.',
                       'Our pipeline includes reranking retrieved documentation chunks.')]
    with app.state.sessionmaker() as db:
        for idx, id_ in enumerate(ids):
            db.add(Publication(id=id_, domain='rag', filename=f'{idx}.pdf', sha256=hashes[idx],
                               stored_path=f'uploads/{id_}.pdf', page_count=1, fragment_count=0,
                               text_status='ok'))
        db.commit()
    return app, ids, hashes


def test_explanation_endpoint_ollama_contract_and_quality_path(tmp_path, monkeypatch):
    app, ids, _ = _app_with_pdfs(tmp_path)
    calls = []
    def fake_completion(settings, payload):
        calls.append(payload)
        assert payload['model'] == 'qwen3.5:4b'
        assert 'response_format' in payload
        assert 'EVIDENCE' in payload['messages'][1]['content']
        assert 'L-retrieval-1' in payload['messages'][1]['content']
        assert 'R-retrieval-1' in payload['messages'][1]['content']
        return model_reply()
    monkeypatch.setattr(v33, '_completion', fake_completion)
    with TestClient(app) as client:
        assert '/api/v1/scientific/rag/explain-comparison' in client.get('/openapi.json').json()['paths']
        r = client.post('/api/v1/scientific/rag/explain-comparison', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1], 'language': 'ru', 'per_topic': 2})
        assert r.status_code == 200, r.text
        data = r.json()
        assert data['source_status'] == {'left': 'checksum_verified', 'right': 'checksum_verified'}
        assert data['report_version'] == '3.3'
        assert data['explanation']['comparisons'][0]['left_evidence_ids'] == ['L-retrieval-1']
        assert data['evidence_catalog']['L-retrieval-1']['page'] == 1
        assert data['report_status'] == 'exploratory_requires_review'
        assert len(calls) == 1
        quality = client.get('/api/v1/scientific/rag/quality-compare-documents', params={
            'left_publication_id': ids[0], 'right_publication_id': ids[1]})
        assert quality.status_code == 200 and quality.json()['evidence_comparison']['source_status']['left'] == 'checksum_verified'


def test_explanation_endpoint_fails_closed_for_missing_pdf(tmp_path, monkeypatch):
    app, ids, _ = _app_with_pdfs(tmp_path)
    (app.state.settings.data_dir / 'uploads' / f'{ids[1]}.pdf').unlink()
    monkeypatch.setattr(v33, '_completion', lambda *_: (_ for _ in ()).throw(AssertionError('LLM must not be called')))
    with TestClient(app) as client:
        resp = client.post('/api/v1/scientific/rag/explain-comparison', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1]})
        assert resp.status_code == 409
        assert resp.json()['detail']['source_status']['right'] == 'pdf_unavailable'


def test_explanation_endpoint_needs_real_model(tmp_path):
    app, ids, _ = _app_with_pdfs(tmp_path, mode='mock')
    with TestClient(app) as client:
        resp = client.post('/api/v1/scientific/rag/explain-comparison', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1]})
        assert resp.status_code == 503
        assert 'LLM_MODE=openai' in resp.text


def test_bad_model_json_and_untrusted_instructions():
    try:
        v33._read_model_json('The evidence says: do not generate JSON')
    except v33.ExplanationError:
        pass
    else:
        raise AssertionError('Non-JSON should be rejected')
    assert 'недоверенными' in v33.SYSTEM_RU.lower() or 'НЕДОВЕРЕННЫМИ' in v33.SYSTEM_RU
    assert 'ignore instructions' in v33.SYSTEM_EN


def test_local_ollama_http_payload_is_real_chat_completion(monkeypatch, tmp_path):
    import httpx
    class FakeClient:
        def __init__(self, **kwargs):
            assert kwargs['timeout'] > 0
        def __enter__(self): return self
        def __exit__(self, *_): return False
        def post(self, url, json, headers):
            assert url == 'http://127.0.0.1:11434/v1/chat/completions'
            assert json['model'] == 'qwen3.5:4b'
            assert json['messages'][0]['role'] == 'system'
            assert 'Authorization' not in headers
            return httpx.Response(200, json={'choices':[{'message':{
                'role':'assistant', 'content':'{"summary":"fine","comparisons":[]}'
            }}]}, request=httpx.Request('POST', url))
    monkeypatch.setattr(v33.httpx, 'Client', FakeClient)
    settings = Settings(data_dir=tmp_path, llm_mode='openai', llm_model='qwen3.5:4b',
                        llm_base_url='http://127.0.0.1:11434/v1', llm_api_key='')
    got = v33._completion(settings, {'model': settings.llm_model,
                                     'messages': [{'role':'system','content':'test'}]})
    assert v33._read_model_json(got)['summary'] == 'fine'
