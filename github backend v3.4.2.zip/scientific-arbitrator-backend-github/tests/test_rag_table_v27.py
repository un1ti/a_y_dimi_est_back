"""v2.7 regression: repeated stored grid fragments must not multiply records."""
from __future__ import annotations
import os
from pathlib import Path
from types import SimpleNamespace

from app.services.rag_table_extraction import extract_rag_table_records
from app.services.rag_pdf_table_recovery import recover_text_aligned_tables
from app.schemas.domain import RagFinding
from app.services.grounding import ground_record


def _fragment(ident, row, *, value='.204', page=6, caption=''):
    return SimpleNamespace(id=ident, page=page, text=(
        f'EXTRACTED TABLE (page {page})\n'
        'Columns: Methods | HotpotQA (EM) [generator=LLaMA3-8B-Instruct]\n'
        + (f'Caption: {caption}\n' if caption else '')
        + f'Row: {row} | {value}'
    ))


def test_duplicate_fragments_are_one_result_and_evidence_combined():
    fragments = [_fragment('old','RA-CoT'), _fragment('new','RA-CoT'),
                 _fragment('extra','ThreadRAG',value='.422')]
    parsed = extract_rag_table_records(fragments, limit=1)
    assert len(parsed.records) == 1
    assert parsed.duplicate_count == 1
    assert parsed.conflicting_groups == 0
    row = parsed.records[0]
    assert row['metric_value'] == .204
    assert {e['fragment_id'] for e in row['evidence']} == {'old','new'}
    refs = {f.id:f for f in fragments}
    _, evidence, removed = ground_record(RagFinding.model_validate(row), refs)
    assert not removed and len(evidence) == 10


def test_conflicts_quarantined_even_if_limit_filled():
    fragments = [_fragment('old','RA-CoT'), _fragment('other','ThreadRAG',value='.422'),
                 _fragment('wrong','RA-CoT',value='.999')]
    parsed = extract_rag_table_records(fragments, limit=1)
    assert parsed.conflicting_groups == 1
    assert [r['rag_variant'] for r in parsed.records] == ['ThreadRAG']


def test_distinct_page_or_caption_not_merged():
    fragments = [_fragment('one','RA-CoT',page=5), _fragment('two','RA-CoT',page=6),
                 _fragment('three','RA-CoT',page=6,caption='Table 5: Different setup')]
    parsed = extract_rag_table_records(fragments)
    assert len(parsed.records) == 3


def test_d001_replayed_old_and_recovered_fragments():
    p=Path(os.getenv('RAG_V27_D001_PDF','/nonexistent/D001.pdf'))
    if not p.is_file():
        return
    recovered=recover_text_aligned_tables(p.read_bytes())
    fragments=[SimpleNamespace(id=f'frag{i}',page=f.page,text=f.text) for i,f in enumerate(recovered)]
    replayed=fragments + [SimpleNamespace(id=f'replay{i}',page=f.page,text=f.text) for i,f in enumerate(recovered[:5])]
    parsed=extract_rag_table_records(replayed,limit=600)
    assert len(parsed.records)==252
    assert parsed.duplicate_count==90
    assert parsed.conflicting_groups==0


def test_p001_replayed_preserves_all_five_tables():
    p=Path(os.getenv('RAG_V27_P001_PDF','/nonexistent/P001.pdf'))
    if not p.is_file():
        return
    recovered=recover_text_aligned_tables(p.read_bytes())
    fragments=[SimpleNamespace(id=f'p{i}',page=f.page,text=f.text) for i,f in enumerate(recovered)]
    parsed=extract_rag_table_records(fragments+fragments,limit=600)
    assert len(parsed.records)==192
    assert parsed.duplicate_count==192
    assert parsed.conflicting_groups==0
