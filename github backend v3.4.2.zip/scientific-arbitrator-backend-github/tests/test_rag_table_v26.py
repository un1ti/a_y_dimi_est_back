"""v2.6: conservative reconstruction from multi-line PDF table cells."""
from __future__ import annotations
import os
from pathlib import Path
from types import SimpleNamespace

from app.services.rag_pdf_table_recovery import _compact_multiline_table, recover_text_aligned_tables
from app.services.rag_table_extraction import extract_rag_table_records
from app.services.grounding import ground_record
from app.schemas.domain import RagFinding


def _extract(pdf_bytes):
    fragments = recover_text_aligned_tables(pdf_bytes)
    sources = {str(i): SimpleNamespace(id=str(i), page=x.page, text=x.text) for i,x in enumerate(fragments)}
    parsed = extract_rag_table_records(sources.values())
    return fragments, sources, parsed


def test_v26_metrics():
    from app.services.rag_table_extraction import _metric_spec, _dataset_from_heading
    for label, canonical, k in [('Recall@15','Recall',15),('BLEU','BLEU',None),('ROUGE-L','ROUGE-L',None),('UniEval','UniEval',None)]:
        assert _metric_spec(label) == (canonical,k)
    assert _dataset_from_heading('ORD-QA#all (ROUGE-L)') == 'ORD-QA#all'


def test_multi_line_cell_alignment_rejects_missing_numeric_value():
    class Table:
        bbox=(0,40,200,100)
        def extract(self):
            return [
                ['RAG Flow','BLEU ROUGE-L UniEval'],
                ['Vanilla-RAG\nRAG-EDA','0.12 0.25 0.7\n0.13 0.4']]
    class Page:
        def get_text(self, what):
            return [(0,10,200,30,'Table 5: Performance on commercial EDA tool.',0,0)]
    assert _compact_multiline_table(Page(),Table(),8) == []


def test_p001_real_source_when_explicitly_supplied():
    path=Path(os.getenv('RAG_V26_P001_PDF','/nonexistent/P001.pdf'))
    if not path.is_file():
        return
    fragments, refs, parsed=_extract(path.read_bytes())
    assert len(fragments)==25
    assert len(parsed.records)==192
    assert {f.page for f in fragments} == {7,8}
    assert not parsed.skipped_rows
    assert len({(r['rag_variant'],r['dataset_name'],r['metric_name'],r.get('metric_k')) for r in parsed.records}) == 192
    examples={
        ('Our embedding model','ORD-QA','Recall',5):.547,
        ('Our reranker','ORD-QA','Recall',5):.671,
        ('RAG-EDA (ours)','ORD-QA#all','BLEU',None):.137,
        ('RAG-EDA (ours)','ORD-QA#all','ROUGE-L',None):.283,
        ('RAG-EDA (ours)','ORD-QA#all','UniEval',None):.729,
        ('RAG-EDA (ours)','Commercial EDA tool QA','UniEval',None):.730,
    }
    # Recall@5 occurs in TWO separately evaluated components, thus need additional
    # component identity before using the two records as a fully unique scientific key.
    for (system,dataset,metric,k), val in examples.items():
        found=[r for r in parsed.records if (r['rag_variant'],r['dataset_name'],r['metric_name'],r.get('metric_k'))==(system,dataset,metric,k)]
        assert len(found)==1,(system,dataset,metric,k,len(found))
        assert found[0]['metric_value']==val
        _, evidence, removed=ground_record(RagFinding.model_validate(found[0]),refs)
        assert removed==[] and len(evidence)>=4


def test_d001_remains_252_when_explicitly_supplied():
    path=Path(os.getenv('RAG_V26_D001_PDF','/nonexistent/D001.pdf'))
    if not path.is_file():
        return
    fragments, refs, parsed=_extract(path.read_bytes())
    assert len(parsed.records)==252
    assert len(fragments)==14
    assert all(f.page==6 for f in fragments)
