from app.services.rag_comparison_v29 import compare_previews, audit_preview

BASE = {'dataset':'ORD-QA','metric':'Recall','metric_k':5,'system':'retrieverA',
        'evaluation_stage':'retrieval','evaluation_protocol':'ranked_top_k', 'split':'test'}

def test_identical_experiment_conditions_with_different_systems():
    assert compare_previews(BASE, dict(BASE,system='retrieverB'))['verdict']=='comparable'

def test_wrong_cutoff_is_incomparable():
    r=compare_previews(BASE,dict(BASE,metric_k=10))
    assert r['verdict']=='incomparable' and 'metric_k' in r['blocking_fields']

def test_stage_is_a_blocker_even_when_metric_matches():
    r=compare_previews(BASE,dict(BASE,evaluation_stage='full_rag'))
    assert r['verdict']=='incomparable' and 'evaluation_stage' in r['blocking_fields']

def test_no_stage_or_protocol_is_not_comparable():
    a={k:v for k,v in BASE.items() if k not in ('evaluation_stage','evaluation_protocol','split')}
    r=compare_previews(a,a)
    assert r['verdict']=='insufficient_data'
    assert set(('evaluation_stage','evaluation_protocol','split')).issubset(r['blocking_fields'])

def test_different_metric_blocks():
    assert compare_previews(BASE,dict(BASE,metric='Precision'))['verdict']=='incomparable'

def test_one_sided_unit_is_not_comparable():
    assert compare_previews(dict(BASE,metric_unit='fraction'),BASE)['verdict']=='insufficient_data'

def test_preview_audit_no_fake_certification():
    r=audit_preview([{'dataset':'ORD-QA','metric':'Recall','metric_k':5,'system':'A','source_page':7},
                     {'dataset':'ORD-QA','metric':'Recall','metric_k':5,'system':'B','source_page':7}])
    assert r['total_records']==2 and r['families'][0]['readiness']=='insufficient_data'

def test_http_endpoint(client):
    r=client.post('/api/v1/scientific/rag/compare-preview',json={'left':BASE,'right':dict(BASE,evaluation_stage='generation')})
    assert r.status_code==200 and r.json()['verdict']=='incomparable'

def test_http_audit_missing_publication(client):
    r=client.get('/api/v1/scientific/rag/comparison-audit',params={'publication_id':'not-found'})
    assert r.status_code==404
