"""v3.4 safety regression tests for scientific explanation claims."""
import hashlib
import json
from uuid import uuid4

import pymupdf
from fastapi.testclient import TestClient

from app.config import Settings
from app.db.models import Publication
from app.main import create_app
from app.services.rag_reasoning_guard_v34 import check_claim, protect_comparison
from app.services.rag_claim_explainer_v33 import (
    _validated_explanation, pdf_explanation_evidence, build_context,
)
import app.services.rag_claim_explainer_v33 as impl


def _fake_response():
    return json.dumps({
        'summary': 'У P001 нет экспериментальных результатов',
        'comparisons': [{
            'topic': 'retrieval',
            'left_method': 'Использует BM25 для поиска документов',
            'right_method': 'Использует BM25 и recall@k для оценки',
            'similarity': 'Обе работы используют BM25',
            'difference': 'Вторая сообщает recall@k',
            'left_advantage': 'не установлено', 'right_advantage': 'не установлено',
            'relationship': 'different_focus',
            'left_evidence_ids': ['L-retrieval-1'],
            'right_evidence_ids': ['R-retrieval-1'],
            'uncertainty': 'Нет подтверждённых совпадений условий',
        }], 'limitations': ['Отсутствие экспериментальных результатов'],
    }, ensure_ascii=False)


def test_rejects_missing_technical_anchors_but_keeps_matching_sources():
    catalog = {'L-embedding-1': {'document': 'L', 'topic': 'embedding',
                                'quote': 'with nomic-embed-text for embeddings'},
               'R-generation-2': {'document': 'R', 'topic': 'generation',
                                  'quote': 'GPT-4 as the generator for vanilla-RAG'} }
    left = check_claim('Использует nomic-embed-text для эмбеддингов узлов графа',
                       ['L-embedding-1'], catalog)
    assert left['status'] == 'unsupported_specifics'
    assert {'node', 'graph'} <= set(left['unsupported_anchor_terms'])
    right = check_claim('Использует GPT-4 как генератор и обучает его',
                        ['R-generation-2'], catalog)
    assert right['status'] == 'unsupported_specifics'
    assert 'training' in right['unsupported_anchor_terms']
    assert 'possible_baseline_context' in right['source_role_hints']
    direct = check_claim('GPT-4 используется как baseline', ['R-generation-2'], catalog)
    assert direct['status'] == 'technical_anchors_present_not_entailment'


def test_cited_only_not_full_catalog():
    catalog = {
        'L-retrieval-1': {'document': 'L', 'topic': 'retrieval', 'quote': 'We use BM25 for retrieval'},
        'L-retrieval-2': {'document': 'L', 'topic': 'retrieval', 'quote': 'recall@k was measured'},
    }
    a = check_claim('BM25 and recall@k', ['L-retrieval-1'], catalog)
    assert a['unsupported_anchor_terms'] == ['recall@k']
    b = check_claim('BM25 and recall@k', ['L-retrieval-1', 'L-retrieval-2'], catalog)
    assert b['status'] == 'technical_anchors_present_not_entailment'


def test_number_absence_and_superiority_are_not_certified():
    catalog = {'L-retrieval-1': {'document': 'L', 'topic': 'retrieval',
                                'quote': 'Chunk size 1200 with 150 overlap, top-5 contexts'}}
    assert check_claim('1200 символов и 150 overlap', ['L-retrieval-1'], catalog)['unsupported_anchor_terms'] == []
    assert 'number:500' in check_claim('500 overlap', ['L-retrieval-1'], catalog)['unsupported_anchor_terms']
    assert 'unproved_absence' in check_claim('Граф не используется', ['L-retrieval-1'], catalog)['unsupported_anchor_terms']
    assert 'unverified_superiority' in check_claim('Этот метод эффективнее', ['L-retrieval-1'], catalog)['unsupported_anchor_terms']


def test_model_output_masks_unsupported_claim_and_summary():
    catalog = {'L-retrieval-1': {'document': 'L', 'topic': 'retrieval',
                                'quote': 'We use BM25 for lexical retrieval.'},
               'R-retrieval-1': {'document': 'R', 'topic': 'retrieval',
                                'quote': 'BM25 based retrieval with vector search.'}}
    obj = _validated_explanation(json.loads(_fake_response()), catalog, language='ru')
    assert obj['summary'].startswith('Найдено тематических сопоставлений: 1')
    comparison = obj['comparisons'][0]
    assert 'Интерпретация модели отклонена' in comparison['right_method']
    assert comparison['left_method'] == 'Использует BM25 для поиска документов'
    assert 'right_method' in comparison['redacted_unsupported_fields']
    assert comparison['claim_support_checks']['right_method']['unsupported_anchor_terms'] == ['recall@k']
    assert not comparison['claim_support_checks']['right_method']['scientific_entailment_verified']
    assert 'model_summary_draft_unverified' not in obj
    assert 'Численные результаты могут присутствовать' in obj['limitations'][0]
    assert obj['scientific_superiority_verdict'] == 'insufficient_data'


def test_real_pdf_regression_blocks_known_v33_misattributions():
    from pathlib import Path
    root = Path('/mnt/data')
    if not ((root / 'D001.pdf').is_file() and (root / 'P001.pdf').is_file()):
        import pytest
        pytest.skip('Real paper fixtures not installed')
    sources = []
    for side, name in [('L', 'D001.pdf'), ('R', 'P001.pdf')]:
        p = root / name
        obj = pdf_explanation_evidence(p, hashlib.sha256(p.read_bytes()).hexdigest(), side=side)
        assert obj['source_status'] == 'checksum_verified'
        sources.append(obj)
    _, catalog = build_context(*sources)
    assert 'graph' in check_claim('nomic-embed-text для эмбеддингов узлов графа',
                                  ['L-embedding-1'], catalog)['unsupported_anchor_terms']
    assert 'training' in check_claim('GPT-4 как генератор и процесс обучения',
                                     ['R-generation-2'], catalog)['unsupported_anchor_terms']
    assert 'recall@k' in check_claim('BM25 и recall@k',
                                     ['R-retrieval-2'], catalog)['unsupported_anchor_terms']


def test_new_endpoint_keeps_old_and_has_optional_numeric_preview(tmp_path, monkeypatch):
    settings = Settings(data_dir=tmp_path / 'data', database_url=f'sqlite:///{tmp_path}/t.db',
                        llm_mode='openai', llm_model='qwen3.5:4b')
    app = create_app(settings)
    uploads = settings.data_dir / 'uploads'
    uploads.mkdir(parents=True, exist_ok=True)
    ids = [str(uuid4()), str(uuid4())]
    for id_ in ids:
        path = uploads / f'{id_}.pdf'
        with pymupdf.open() as pdf:
            p = pdf.new_page()
            p.insert_text((50, 100), 'We use BM25 and vector retrieval for document search.')
            pdf.save(path)
        with app.state.sessionmaker() as db:
            db.add(Publication(id=id_, domain='rag', filename=id_ + '.pdf',
                               sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                               stored_path=f'uploads/{id_}.pdf', page_count=1, fragment_count=0,
                               text_status='ok'))
            db.commit()
    monkeypatch.setattr(impl, '_completion', lambda *_: _fake_response())
    with TestClient(app) as client:
        paths = client.get('/openapi.json').json()['paths']
        assert '/api/v1/scientific/rag/explain-comparison' in paths
        assert '/api/v1/scientific/rag/explain-comparison-v34' in paths
        resp = client.post('/api/v1/scientific/rag/explain-comparison-v34', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1]})
        assert resp.status_code == 200, resp.text
        data = resp.json()
        assert data['report_version'] == '3.4'
        assert data['numeric_summary'] is None
        assert data['explanation']['support_guard_version'] == '3.4'
        assert data['source_status'] == {'left': 'checksum_verified', 'right': 'checksum_verified'}
        assert data['explanation']['semantic_entailment_verified'] is False
        # Old frontend contract remains valid.
        legacy = client.post('/api/v1/scientific/rag/explain-comparison', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1]})
        assert legacy.status_code == 200 and legacy.json()['report_version'] == '3.3'


def test_demo_page_is_served_same_origin_without_external_scripts(tmp_path):
    app = create_app(Settings(data_dir=tmp_path, database_url=f'sqlite:///{tmp_path}/db.sqlite'))
    with TestClient(app) as client:
        response = client.get('/api/v1/scientific/rag/demo-v34')
        assert response.status_code == 200
        assert response.headers['content-type'].startswith('text/html')
        assert 'Scientific Arbitrator' in response.text
        assert 'explain-comparison-v34' in response.text
        assert 'https://cdn' not in response.text
        assert 'textContent' in response.text


def test_numeric_summary_opt_in_is_separate_and_uncertified(tmp_path, monkeypatch):
    import app.api.rag_evidence_routes as routes
    settings = Settings(data_dir=tmp_path / 'data', database_url=f'sqlite:///{tmp_path}/db.sqlite',
                        llm_mode='openai', llm_model='qwen3.5:4b')
    app = create_app(settings)
    uploads = settings.data_dir / 'uploads'
    uploads.mkdir(parents=True, exist_ok=True)
    ids = [str(uuid4()), str(uuid4())]
    for id_ in ids:
        path = uploads / f'{id_}.pdf'
        with pymupdf.open() as pdf:
            page = pdf.new_page()
            page.insert_text((50, 100), 'We use BM25 and vector retrieval for document search.')
            pdf.save(path)
        with app.state.sessionmaker() as db:
            db.add(Publication(id=id_, domain='rag', filename=id_ + '.pdf',
                               sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                               stored_path=f'uploads/{id_}.pdf', page_count=1, fragment_count=0,
                               text_status='ok'))
            db.commit()
    looked_up = []
    def fake_preview(publication_id, request, limit, db):
        looked_up.append(publication_id)
        row = {'system':'A', 'dataset': 'ORD-QA' if publication_id == ids[0] else 'HotpotQA',
               'metric':'recall' if publication_id == ids[0] else 'f1',
               'metric_k':5 if publication_id == ids[0] else None,'value':0.5}
        return {'records': [row]}
    monkeypatch.setattr(routes, 'rag_table_preview', fake_preview)
    payloads = []
    def fake_completion(settings, payload):
        payloads.append(payload)
        return _fake_response()
    monkeypatch.setattr(impl, '_completion', fake_completion)
    with TestClient(app) as client:
        resp = client.post('/api/v1/scientific/rag/explain-comparison-v34', json={
            'left_publication_id': ids[0], 'right_publication_id': ids[1],
            'include_numeric_summary': True})
        assert resp.status_code == 200, resp.text
        data = resp.json()
        assert looked_up == ids
        assert data['numeric_summary']['left_record_count'] == 1
        assert data['numeric_summary']['right_record_count'] == 1
        assert data['numeric_summary']['shared_family_count'] == 0
        assert data['numeric_summary']['overall_verdict'] == 'insufficient_data'
        assert data['explanation']['numeric_results_status'] == 'preview_supplied_not_certified'
        assert 'numeric_preview_unverified' in payloads[0]['messages'][1]['content']
        assert data['explanation']['scientific_superiority_verdict'] == 'insufficient_data'
