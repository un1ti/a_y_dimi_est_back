from types import SimpleNamespace
from app.services.rag_evidence_v30 import collect_evidence, compare_documents, enriched_audit, stage_hint

def test_evidence_quotes_are_not_certified():
    f=[SimpleNamespace(id='f1',page=3,text='We evaluate retrieval using a held-out test set.\nAnother line'),
       SimpleNamespace(id='f2',page=4,text='EXTRACTED TABLE (x)\nRow: reranker | 0.5')]
    result=collect_evidence(f)
    assert result['verification_status']=='not_verified'
    assert result['verified_context']['split'] is None
    assert result['candidates']['split'][0]['fragment_id']=='f1'
    assert not result['candidates']['evaluation_stage'][0]['status']=='verified'

def test_retrieval_and_reranking_stage_hints_do_not_certify():
    a={'system':'text-embedding-ada-002','dataset':'ORD-QA','metric':'Recall','metric_k':5}
    b=dict(a,system='bge-reranker-large')
    result=enriched_audit([a,b])
    assert result['families'][0]['mixed_stage_hints']
    assert result['families'][0]['readiness']=='insufficient_data'
    assert not stage_hint(b)['stage_verified']

def test_file_compare_keeps_shared_families_but_no_certification():
    a={'system':'A','dataset':'ORD-QA','metric':'Recall','metric_k':5,'value':.5,'source_page':7,'fragment_id':'a'}
    b=dict(a,value=.6,fragment_id='b')
    result=compare_documents([a],[b])
    assert result['shared_family_count']==1
    assert result['reported_value_difference_count']==1
    assert result['overall_verdict']=='insufficient_data'
    assert 'not_certified_contradiction' in result['reported_value_difference_examples'][0]['status']

def test_no_overlap_and_ambiguous_duplicates():
    a={'system':'A','dataset':'one','metric':'BLEU','value':.1}
    b={'system':'B','dataset':'two','metric':'F1','value':.5}
    assert compare_documents([a],[b])['shared_family_count']==0
    assert compare_documents([a,a],[a])['ambiguous_key_pairs']==1

def test_api_missing_documents(client):
    r=client.get('/api/v1/scientific/rag/compare-documents',params={'left_publication_id':'x','right_publication_id':'y'})
    assert r.status_code==404
    assert client.get('/api/v1/scientific/rag/evidence-audit',params={'publication_id':'x'}).status_code==404
