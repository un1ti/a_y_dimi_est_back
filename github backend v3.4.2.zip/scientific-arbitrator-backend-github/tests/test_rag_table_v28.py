"""v2.8 source-preserving dataset alias and actionable skip diagnostics."""
from types import SimpleNamespace
from app.api.rag_table_routes import _dataset_display
from app.services.rag_table_extraction import extract_rag_table_records


def f(id, head, rows):
    return SimpleNamespace(id=id, page=8, text="\n".join([
        "EXTRACTED TABLE (page 8)", "Columns: RAG Flow | " + head,
        *["Row: " + r for r in rows],
    ]))


def test_verified_alias_and_other_dataset_untouched():
    assert _dataset_display("ORD-QA#vlsi-folw") == ("ORD-QA#vlsi-flow", True)
    assert _dataset_display("ORD-QA#vlsi-flow") == ("ORD-QA#vlsi-flow", False)
    assert _dataset_display("OtherQA#vlsi-folw") == ("OtherQA#vlsi-folw", False)


def test_keep_raw_evidence_and_dataset_field_for_grounding():
    p=extract_rag_table_records([f("a", "ORD-QA#vlsi-folw (BLEU)", ["RAG-EDA | .137"])])
    assert len(p.records)==1
    assert p.records[0]["dataset_name"]=="ORD-QA#vlsi-folw"
    assert "ORD-QA#vlsi-folw" in p.records[0]["evidence"][1]["quote"]
    assert p.skipped_rows == 0


def test_skips_report_reason_and_source_without_guessing():
    p=extract_rag_table_records([f("a", "ORD-QA (BLEU)", [
        "RAG-EDA | .137", "Broken | .200 | .300", " | .600", "RAG-EDA | .400",
    ])])
    assert len(p.records)==0  # two values conflict, fail closed
    assert p.skipped_rows==2
    assert [x["reason"] for x in p.skipped_details]==[
        "column_count_mismatch", "missing_system"]
    assert p.skipped_details[0]["page"]==8


def test_identical_fragments_remain_deduplicated():
    a=f("a", "ORD-QA#vlsi-folw (BLEU)", ["RAG-EDA | .137"])
    b=f("b", "ORD-QA#vlsi-folw (BLEU)", ["RAG-EDA | .137"])
    p=extract_rag_table_records([a,b])
    assert len(p.records)==1 and p.duplicate_count==1
